/* global QUnit */
QUnit.config.autostart = false;

sap.ui.getCore().attachInit(function () {
	"use strict";

	sap.ui.require([
		"de/deka/xssui5/zdhr_LohnsteuerBescheinigung/test/integration/AllJourneys"
	], function () {
		QUnit.start();
	});
});