sap.ui.define([
	"de/deka/xssui5/zdhr_LohnsteuerBescheinigung/test/unit/controller/View1.controller"
], function () {
	"use strict";
});