sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/PDFViewer"
], function (Controller, PDFViewer) {
	"use strict";

	return Controller.extend("de.deka.xssui5.zdhr_LohnsteuerBescheinigung.controller.View1", {
		onInit: function () {
			this._pdfViewer = new sap.m.PDFViewer();
			this.getView().addDependent(this._pdfViewer);

		},
		showPDF: function (oEvent) {

			var sPeriod = oEvent.getSource().getBindingContext().getObject().Period;
			var sSource = this.getView().getModel().sServiceUrl + "/PERIODSet('" + encodeURIComponent(sPeriod) + "')" + '/$value';
			//window.open(sSource );

			this._pdfViewer.setSource(sSource);
			this._pdfViewer.setTitle("Lohnsteuerbescheinigung");
			this._pdfViewer.open();

		}

	});

});